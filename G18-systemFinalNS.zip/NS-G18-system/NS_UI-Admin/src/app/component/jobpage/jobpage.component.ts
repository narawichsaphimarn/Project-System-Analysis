import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jobpage',
  templateUrl: './jobpage.component.html',
  styleUrls: ['./jobpage.component.css']
})

export class JobpageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  panelOpenState = false;
}
